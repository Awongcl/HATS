#include "mbed.h"
#include "mbed_rpc.h"
#include "I2C.h"
#include <iostream>
#include "RPC_Ethernet.h"
#include "RPC_I2C.h"
#include "RPC_SDCard.h"
#include "RPC_SPI.h"
#include "RPC_UART.h"
#include "RPC_USBMSD.h"
#include "SerialRPCInterface.h"

//Library used for development
#include "LIS3DSH.h" //Library is configured to run on SPI
#include "TMP102.h"

/* RPC General Note: 
*  Maximum argument input is 4 for every function
*  RPC protocol is sensitive to 'space' and '/' inputing any of the 2 as part of an argument will affect the workings of RPC
*  
*/


Serial pc(USBTX, USBRX);


//RPC Functions
//I2C
RPCFunction rpcI2C_setup(&I2C_setup,"I2C_setup");
RPCFunction rpcI2C_freq(&I2C_freq,"I2C_freq");
RPCFunction rpcI2C_write1(&I2C_write1,"I2C_write1");
RPCFunction rpcI2C_write2(&I2C_write2,"I2C_write2");
RPCFunction rpcI2C_read(&I2C_read,"I2C_read");
RPCFunction rpcI2C_scan(&I2C_scan,"I2C_scan");

//SPI
RPCFunction rpcSPI_pinsetup(&SPI_pinsetup,"SPI_pinsetup");
RPCFunction rpcSPI_cssetup(&SPI_cssetup,"SPI_cssetup");
RPCFunction rpcSPI_format(&SPI_format,"SPI_format");
RPCFunction rpcSPI_freq(&SPI_freq,"SPI_freq");
RPCFunction rpcSPI_read(&SPI_read,"SPI_read");
RPCFunction rpcSPI_write(&SPI_write,"SPI_write");
RPCFunction rpcSPI_rvalue(&SPI_rvalue,"SPI_rvalue");
RPCFunction rpcSPI_wvalue(&SPI_wvalue,"SPI_wvalue");
RPCFunction rpcSPI_devselect(&SPI_devselect,"SPI_devselect");

//UART
RPCFunction rpcUART_setup(&UART_setup,"UART_setup");
RPCFunction rpcUART_baud(&UART_baud,"UART_baud");
RPCFunction rpcUART_format(&UART_format,"UART_format");
//RPCFunction rpcUART_flowctr(&UART_flowctr,"UART_flowctr");
RPCFunction rpcUART_write(&UART_write,"UART_write");
RPCFunction rpcUART_read(&UART_read,"UART_read");
RPCFunction rpcUART_writeread(&UART_writeread,"UART_writeread");
RPCFunction rpcUART_newline(&UART_newline,"UART_newline");
//TODO: UART Flow control, feature not available on Mbed OS 5.9.3 (current version)

//Ethernet
RPCFunction rpcEth_staticvar(&Eth_staticvar,"Eth_staticvar");
RPCFunction rpcEth_readvar(&Eth_readvar,"Eth_readvar");
RPCFunction rpcEth_static(&Eth_static,"Eth_static");
RPCFunction rpcEth_DHCP(&Eth_DHCP,"Eth_DHCP");

//USBMSD
RPCFunction rpcUSBMSD_filesize(&USBMSD_filesize,"USBMSD_filesize");
RPCFunction rpcUSBMSD_info(&USBMSD_info,"USBMSD_info");
RPCFunction rpcUSBMSD_read(&USBMSD_read,"USBMSD_read");
RPCFunction rpcUSBMSD_write(&USBMSD_write,"USBMSD_write");
RPCFunction rpcUSBMSD_append(&USBMSD_append,"USBMSD_append");

//SDCard
RPCFunction rpcSDCard_setup(&SDCard_setup,"SDCard_setup");
RPCFunction rpcSDCard_info(&SDCard_info,"SDCard_info");
RPCFunction rpcSDCard_freq(&SDCard_freq,"SDCard_freq");
RPCFunction rpcSDCard_filesize(&SDCard_filesize,"SDCard_filesize");
RPCFunction rpcSDCard_read(&SDCard_read,"SDCard_read");
RPCFunction rpcSDCard_write(&SDCard_write,"SDCard_write");
RPCFunction rpcSDCard_append(&SDCard_append,"SDCard_append");


int main() 
{   
    //RPC Init
    pc.printf("Start\n");
    char inbuf[1024], outbuf[1024];
  
    RPC::add_rpc_class<RpcDigitalIn>();
    RPC::add_rpc_class<RpcDigitalOut>();
    RPC::add_rpc_class<RpcDigitalInOut>();
//    RPC::add_rpc_class<RpcPwmOut>();
//    RPC::add_rpc_class<RpcTimer>();

    while (1) {
        pc.gets(inbuf,1024);
        RPC::call(inbuf, outbuf);
        pc.printf("%s\n",outbuf);
    }
    
}
