#ifndef TMP102_h
#define TMP102_h

#define TMP102_TEMP_REG     0x00
#define TMP102_CONFIG_REG   0x01
#define TMP102_TEMP_LREG    0x02
#define TMP102_TEMP_HREG    0x03




#endif
