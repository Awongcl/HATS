#include "mbed_rpc.h"
#include <iostream>
#include "RPC_SPI.h"
#include "mbed.h"
#include "SPI.h"

/* RPC SPI Notes
* SPI_pinsetup & SPI_cssetup function must be called first before other functions. Pins for SPI_MOSI, SPI_MISO & SPI_SCK must be declared successfully prior to usage
*/

//Variables
int SPIread = 1;
int SPIwrite = 0;
int spidevice = 0; //Default devselect
int spibits = 7; //Default of 8 bits per frame


//SPI Set-up
PinName SPIMOSI, SPIMISO, SPISCK;
SPI *spi;

//SPI Chip Select Pins
PinName CS0,CS1,CS2;
DigitalOut *spics0;
DigitalOut *spics1;
DigitalOut *spics2;


//Set pin for SPI_MOSI, SPI_MISO and SPI_SCK
//Arg1: MOSI pin, Arg2: MISO pin, Arg3: SCK pin
void SPI_pinsetup(Arguments *input,Reply *output){
    SPIMOSI = input->getArg<PinName>();
    SPIMISO = input->getArg<PinName>();
    SPISCK = input->getArg<PinName>();
    
    spi = new SPI(SPIMOSI, SPIMISO, SPISCK);
    output->putData("SPI pin setup done!");
    
    return;
    }


//Setup for 3 SPI Chip Select pins
//Arg1: CS pin 1, Arg2: CS pin 2, Arg3: CS pin 3    
void SPI_cssetup(Arguments *input,Reply *output){
    CS0 = input->getArg<PinName>();
    CS1 = input->getArg<PinName>();
    CS2 = input->getArg<PinName>();
    
    spics0 = new DigitalOut(CS0);
    spics1 = new DigitalOut(CS1);
    spics2 = new DigitalOut(CS2);
    output->putData("SPI cs setup done!");
    
    return;
    }

/*  @param bits Number of bits per SPI frame (4 - 16).
 *  @param mode Clock polarity and phase mode (0 - 3).
 * mode | POL PHA
 * -----+--------
 *   0  |  0   0
 *   1  |  0   1
 *   2  |  1   0
 *   3  |  1   1 */
//Setup for SPI Format (bits, mode)
//Arg1: Bits, Arg2: Mode
void SPI_format(Arguments *input,Reply *output){
    spics0->write(1); //Ensure deselect
    spics1->write(1); //Ensure deselect
    spics2->write(1); //Ensure deselect
    int bits = input->getArg<int>();
    int mode = input->getArg<int>();
    char data[256];
    
    if((4<= bits <= 16) && (0 <= mode <= 3)){
        spi->format(bits,mode);
        spibits = bits - 1;
        sprintf(data,"SPI bits per frame: %d, mode: %d",bits,mode);
        output->putData(data);
        }
    else{
        output->putData("Invalid Input");
        }
        
    return;
    }


//Set SPI frequency
//Arg1: Frequency
void SPI_freq(Arguments *input,Reply *output){
    spics0->write(1); //Ensure deselect
    spics1->write(1); //Ensure deselect
    spics2->write(1); //Ensure deselect
    int hz = input->getArg<int>();
    char data[256];
    
    spi->frequency(hz);
    sprintf(data,"Frequency set to: %d Hz",hz);
    output->putData(data);
    
    return;
    }


//Change read value
//Arg1: SPI read value
void SPI_rvalue(Arguments *input,Reply *output){
    int val = input->getArg<int>();
    char data[256];
    
    if((val == 1) || (val == 0)){
        SPIread = val;
        sprintf(data,"SPI Read Value = %d",val);
        output->putData(data);
        }
    else{
        output->putData("Invalid input");
        }
        
    return;
    }
    
    
//Change write value
//Arg1: SPI write value
void SPI_wvalue(Arguments *input,Reply *output){
    int val = input->getArg<int>();
    char data[256];
    
    if((val == 1) || (val == 0)){
        SPIwrite = val;
        sprintf(data,"SPI Write Value = %d",val);
        output->putData(data);
        }
    else{
        output->putData("Invalid input");
        }
        
    return;
    }

//non-rpc function
void spiselect(){
    if(spidevice == 0){
        spics0->write(0);
        }
    else if(spidevice == 1){
        spics1->write(0);
        }
    else if(spidevice == 2){
        spics2->write(0);
        }
    return;
    }
    
//non-rpc function    
void spideselect(){
    if(spidevice == 0){
        spics0->write(1);
        }
    else if(spidevice == 1){
        spics1->write(1);
        }
    else if(spidevice == 2){
        spics2->write(1);
        }
    return;
    }


//Select CS pin   
//Arg1: CS pin to select (0-2)
void SPI_devselect(Arguments *input,Reply *output){
    int dev = input->getArg<int>();
    
    if((dev == 0) || (dev == 1) || (dev == 2)){
        spidevice = dev;
        if(dev == 0){
            output->putData("Device with CS pin CS0 Selected");
            }
        else if(dev == 1){
            output->putData("Device with CS pin CS1 Selected");
            }
        else if(dev == 2){
            output->putData("Device with CS pin CS2 Selected");
            }
        }
    else{
        output->putData("Invalid argument");
        }
        
    return;
    }


//SPI Write 1 byte
//Arg1: Register Address, Arg2: Data to be written
void SPI_write(Arguments *input,Reply *output){
    spi->lock();
    spiselect();
    int addr = input->getArg<int>();
    int val = input->getArg<int>();
    
    spi->write( (SPIwrite<<spibits) | addr);
    spi->write(val);
    
    spideselect();
    spi->unlock();
    output->putData("Written");
    
    return;
    }


//SPI Read 1 Byte
//Arg1: Register Address
void SPI_read(Arguments *input,Reply *output){
    spi->lock();
    spiselect();
    int ret;
    char data[256];
    int addr = input->getArg<int>();
    
    spi->write( (SPIread<<spibits) | addr);
    ret = spi->write(0x00);
    
    spideselect();
    spi->unlock();
    sprintf(data,"Byte1 = %i",ret);
    output->putData(data);
    
    return;
    }