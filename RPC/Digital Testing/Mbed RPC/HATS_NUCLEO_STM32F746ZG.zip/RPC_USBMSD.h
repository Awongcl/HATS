#ifndef RPC_USBMSD_H
#define RPC_USBMSD_H


void USBMSD_info(Arguments *input,Reply *output);


void USBMSD_filesize(Arguments *input,Reply *output);


void USBMSD_read(Arguments *input,Reply *output);


void USBMSD_write(Arguments *input,Reply *output);


void USBMSD_append(Arguments *input,Reply *output);


#endif