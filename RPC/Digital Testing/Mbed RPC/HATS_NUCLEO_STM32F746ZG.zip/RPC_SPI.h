#ifndef RPC_SPI_H
#define RPC_SPI_H


void SPI_pinsetup(Arguments *input,Reply *output);


void SPI_cssetup(Arguments *input,Reply *output);


void SPI_format(Arguments *input,Reply *output);


void SPI_freq(Arguments *input,Reply *output);


void SPI_rvalue(Arguments *input,Reply *output);


void SPI_wvalue(Arguments *input,Reply *output);


void spiselect();
    
    
void spideselect();


void SPI_devselect(Arguments *input,Reply *output);


void SPI_write(Arguments *input,Reply *output);


void SPI_read(Arguments *input,Reply *output);















#endif