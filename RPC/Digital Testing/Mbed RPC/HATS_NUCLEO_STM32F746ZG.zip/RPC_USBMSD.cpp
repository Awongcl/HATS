#include "mbed_rpc.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "RPC_USBMSD.h"
#include "mbed.h"
#include "FATFileSystem.h"
#include "time.h"
#include "USBHostMSD.h"

/*USBMSD Notes
* Directory addressing is restricted due to RPC recognition of '/' as part of their protocol
  Possible to assign a letter/symbol to replace '/' for directory addressing */


USBHostMSD usbmsd; //Cause LD8 to light up (NUCLEO-FZ746ZG)
FATFileSystem fs("fs");


//Properties of the MSD Device in Block Sizes
//No Argument
void USBMSD_info(Arguments *input,Reply *output){
    char data[1024];
    int size = usbmsd.size(); //Equivalent to calling Read Capacity
    
    //Returns the same thing (Blocksize), added in case there are difference for other flash drives
    int rsize = usbmsd.get_read_size();
    int psize = usbmsd.get_program_size();
    int esize = usbmsd.get_erase_size();
    
    sprintf(data,"Drive Size:%d ,Read Block Size:%d , Program Block Size:%d , Erase Block Size:%d",size,rsize,psize,esize);
    output->putData(data);
    
    return;
    }


//Open a file and return the size of file in bytes
//Arg1: file name
void USBMSD_filesize(Arguments *input,Reply *output){
    int connect_ctr = 0;
    char fpath[1024], data[1024];
    long int fsize;
    
    int dev_stat = usbmsd.connected(); //Check if device is still connected
    if (dev_stat != 1){ //If not connected, connect
        while( dev_stat != 1){
            dev_stat = usbmsd.connect();
            wait(1);
            if(connect_ctr == 10){ //Timeout for connecting MSD
                output->putData("Unable to connect MSD");
                return;
                }
            connect_ctr++;
            }
        }
        
    int mount = fs.mount(&usbmsd);
    if(mount != 0){
        output->putData("Fail to mount to FATfs");
        return;
        }
        
    const char* path = input->getArg<const char*>();
    sprintf(fpath,"/fs/%s",path); //Unable to navigate a folder since "/" is a symbol sensitive to RPC
    
    FILE *file = fopen(fpath,"r"); //a for append, r for read, w for write, add b at the end to do it in binary form
    if(file == NULL){
        output->putData("Error in opening file");
        return;
        }
        
    fseek(file,0,SEEK_END);
    fsize = ftell(file);
    sprintf(data,"Size of file: %d bytes",fsize);
    fclose(file);
    fs.unmount();
    output->putData(data);
    
    return;
    }
    
    
//fread method gives additional random character (Replaced with reading character by character)
//Open and read on an existing file, Error if file do not exist
//Arg1: file name
//void USBMSD_read(Arguments *input,Reply *output){
//    char *odata;
//    char data[1024],fpath[1024];
//    long int fsize,r_ctr;
//    long int len = 0;
//    int connect_ctr = 0;
//    int err;
//    int dev_stat = usbmsd.connected(); //Check if device is still connected
//    if (dev_stat != 1){ //If not connected, connect
//        while( dev_stat != 1){
//            dev_stat = usbmsd.connect();
//            wait(1);
//            if(connect_ctr == 10){ //Timeout for connecting MSD
//                output->putData("Unable to connect MSD");
//                return;
//                }
//            connect_ctr++;
//            }
//        }
//    int mount = fs.mount(&usbmsd);
//    if(mount != 0){
//        output->putData("Fail to mount to FATfs");
//        return;
//        }
//    const char* path = input->getArg<const char*>();
//    sprintf(fpath,"/fs/%s",path); //Unable to navigate a folder since "/" is a symbol sensitive to RPC
//    FILE *file = fopen(fpath,"r"); //a for append, r for read, w for write, add b at the end to do it in binary form
//    if(file == NULL){
//        output->putData("Error in opening file");
//        return;
//        }
//    fseek(file,0,SEEK_END);
//    fsize = ftell(file);
//    rewind(file); //Set pointer back to the beginning 
//      
//    if(fsize > 900){
//        odata = (char *)malloc(900); //Setting size equivalent to file size
//        if(odata == NULL){
//            output->putData("Memory allocation error\n");
//            return;
//            }
//        r_ctr = fread(odata,1,900,file);
//        if(r_ctr != 900){
//            output->putData("Reading file error");
//            return;
//            }
//        len += sprintf(data + len,"File Size: %d, Only first 900 Bytes shown\n",fsize);
//        }        
//    else{     
//        odata = (char *)malloc(fsize); //Setting size equivalent to file size
//        if(odata == NULL){
//            output->putData("Memory allocation error\n");
//            return;
//            }
//        r_ctr = fread(odata,1,fsize,file);
//        if(r_ctr != fsize){
//            output->putData("Reading file error");
//            return;
//            }
//        len += sprintf(data + len,"File Size: %d\n",fsize);
//        }
//    err = ferror(file);
//    if(err !=0){
//        len += sprintf(data + len,"File Error flag raised\n");
//        }
//    fclose(file);
//    fs.unmount();
//    len += sprintf(data + len,"File Data: %s",odata);
//    output->putData(data);
//    return;
//    }


//Open and read on an existing file, Error if file do not exist
//Arg1: file name
void USBMSD_read(Arguments *input,Reply *output){
    char odata[900],data[1024],fpath[1024];
    long int fsize;
    long int len = 0, r_ctr = 0;
    int connect_ctr = 0;
    int err, c;
    
    int dev_stat = usbmsd.connected(); //Check if device is still connected
    if (dev_stat != 1){ //If not connected, connect
        while( dev_stat != 1){
            dev_stat = usbmsd.connect();
            wait(1);
            if(connect_ctr == 10){ //Timeout for connecting MSD
                output->putData("Unable to connect MSD");
                return;
                }
            connect_ctr++;
            }
        }
        
    int mount = fs.mount(&usbmsd);
    if(mount != 0){
        output->putData("Fail to mount to FATfs");
        return;
        }
        
    const char* path = input->getArg<const char*>();
    sprintf(fpath,"/fs/%s",path); //Unable to navigate a folder since "/" is a symbol sensitive to RPC
    FILE *file = fopen(fpath,"r"); //a for append, r for read, w for write, add b at the end to do it in binary form
    if(file == NULL){
        output->putData("Error in opening file");
        return;
        }
        
    fseek(file,0,SEEK_END);
    fsize = ftell(file);
    rewind(file); //Set pointer back to the beginning 
      
    if(fsize > 900){
            while(1) {
                c = fgetc(file);
                r_ctr++;
                if( feof(file) || r_ctr == 901) { 
                    break ;
                    }
            len += sprintf(odata + len,"%c",c);
            }
        if(r_ctr != 901){
            output->putData("Reading file error");
            return;
            }
        len = 0; //Reset len for "data"
        len += sprintf(data + len,"File Size: %d, Only first 900 Bytes shown\n",fsize);
        }        
    else{     
        while(1) {
            c = fgetc(file);
            if(feof(file)) { 
                break ;
                }
        len += sprintf(odata + len,"%c",c);
        r_ctr++;
        }
        if(r_ctr != fsize){
            output->putData("Reading file error");
            return;
            }
        len = 0; //Reset len for "data"
        len += sprintf(data + len,"File Size: %d\n",fsize);
        }
        
    err = ferror(file);
    if(err !=0){
        len += sprintf(data + len,"File Error flag raised\n");
        }
        
    fclose(file);
    fs.unmount();
    len += sprintf(data + len,"File Data: %s",odata);
    output->putData(data);
    
    return;
    }    
    
    
//Create/Overwrite a file and write
//Arg1: file name, Arg2: Data to write
void USBMSD_write(Arguments *input,Reply *output){
    int connect_ctr = 0;
    char fpath[1024];
    
    int dev_stat = usbmsd.connected(); //Check if device is still connected
    if (dev_stat != 1){ //If not connected, connect
        while( dev_stat != 1){
            dev_stat = usbmsd.connect();
            wait(1);
            if(connect_ctr == 10){ //Timeout for connecting MSD
                output->putData("Unable to connect MSD");
                return;
                }
            connect_ctr++;
            }
        }
        
    int mount = fs.mount(&usbmsd);
    if(mount != 0){
        output->putData("Fail to mount to FATfs");
        return;
        }
        
    const char* path = input->getArg<const char*>();
    sprintf(fpath,"/fs/%s",path); //Unable to navigate a folder since "/" is a symbol sensitive to RPC
    
    FILE *file = fopen(fpath,"w"); //a for append, r for read, w for write, add b at the end to do it in binary form
    if(file == NULL){
        output->putData("Error in opening file");
        return;
        }
        
    const char* idata = input->getArg<const char*>();    
    int suc = fwrite(idata,1,strlen(idata),file);//Arg: buffer pointer, size in bytes, number of elements each in size length, file 
    if (suc == strlen(idata)){ //Success in writing into file
        output->putData("Written");
        }
    else{
        output->putData("Error in writing to file");
        }

    fclose(file);
    fs.unmount();    
    
    return;
    }
    
    
//Append on an existing file or create a file and write
//Arg1: file name, Arg2: Data to write/append
void USBMSD_append(Arguments *input,Reply *output){
    int connect_ctr = 0;
    char fpath[1024];
    
    int dev_stat = usbmsd.connected(); //Check if device is still connected
    if (dev_stat != 1){ //If not connected, connect
        while( dev_stat != 1){
            dev_stat = usbmsd.connect();
            wait(1);
            if(connect_ctr == 10){ //Timeout for connecting MSD
                output->putData("Unable to connect MSD");
                return;
                }
            connect_ctr++;
            }
        }
        
    int mount = fs.mount(&usbmsd);
    if(mount != 0){
        output->putData("Fail to mount to FATfs");
        return;
        }
        
    const char* path = input->getArg<const char*>();
    sprintf(fpath,"/fs/%s",path); //Unable to navigate a folder since "/" is a symbol sensitive to RPC
    
    FILE *file = fopen(fpath,"a"); //a for append, r for read, w for write, add b at the end to do it in binary form
    if(file == NULL){
        output->putData("Error in opening file");
        return;
        }
        
    const char* idata = input->getArg<const char*>();    
    int suc = fwrite(idata,1,strlen(idata),file);//Arg: buffer pointer, size in bytes, number of elements each in size length, file 
    if (suc == strlen(idata)){ //Success in writing into file
        output->putData("Written");
        }
    else{
        output->putData("Error in writing to file");
        }

    fclose(file);
    fs.unmount();
    
    return;
    }
