#include "mbed_rpc.h"
#include "RPC_SDCard.h"
#include "mbed.h"
#include "SDBlockDevice.h"
#include "FATFileSystem.h"


/*USBMSD Notes
* Directory addressing is restricted due to RPC recognition of '/' as part of their protocol
* Possible to assign a letter/symbol to replace '/' for directory addressing 
*
* Set-up Function has to be called first before other functions
*/


//Set-up
SDBlockDevice *sdcard;
FATFileSystem fatfs("fatfs");
PinName SDMOSI, SDMISO, SDSCK, SDCS; //PC_12, PC_11, PC_10, PC_9 (Sensorpod)


//Pin set-up for SDCard (SPI Interface)
//Arg1: MOSI, Arg2: MISO, Arg3: SCK, Arg4: CS
void SDCard_setup(Arguments *input,Reply *output){
    SDMOSI = input->getArg<PinName>();
    SDMISO = input->getArg<PinName>();
    SDSCK = input->getArg<PinName>();
    SDCS = input->getArg<PinName>();
    
    sdcard = new SDBlockDevice(SDMOSI,SDMISO,SDSCK,SDCS);
    
    output->putData("SDCard pin setup done!");
    return;
    }

//Propetries of SDCard in Block Sizes
//No argument
void SDCard_info(Arguments *input,Reply *output){
    char data[1024];
    
    int rsize = sdcard->get_read_size();
    int psize = sdcard->get_program_size();
    
    sprintf(data,"Read Block Size: %d , Program Block Size: %d",rsize,psize);
    output->putData(data);   
    return; 
    }


//Set frequency of SDCard SPI Communication interface
//Arg1: Freq in Hz
void SDCard_freq(Arguments *input,Reply *output){
    int freq = input->getArg<int>();
    char data[256];
    if (freq <= 25000000 && freq >0){ //Max freq supported: 25MHz
        sdcard->frequency(freq);
        sprintf(data,"Frequency: %d Hz",freq);
        output->putData(data);
        }
    else{
        output->putData("Invalid Input");
        }
    return;
    }


//Open a file and return the size of file in bytes
//Arg1: file name
void SDCard_filesize(Arguments *input,Reply *output){
    char fpath[1024], data[1024];
    long int fsize;
    
    int dev_stat = sdcard->init(); //Check if device is initialized
    if (dev_stat != 0){ //Init failed
        output->putData("Fail to initialize blockdevice");
        return;
        }
        
    int mount = fatfs.mount(sdcard);
    if(mount != 0){
        output->putData("Fail to mount to FATfs");
        return;
        }
        
    const char* path = input->getArg<const char*>();
    sprintf(fpath,"/fatfs/%s",path); //Unable to navigate a folder since "/" is a symbol sensitive to RPC
    
    FILE *file = fopen(fpath,"r"); //a for append, r for read, w for write, add b at the end to do it in binary form
    if(file == NULL){
        output->putData("Error in opening file");
        return;
        }
        
    fseek(file,0,SEEK_END);
    fsize = ftell(file);
    sprintf(data,"Size of file: %d bytes",fsize);
    fclose(file);
    
    fatfs.unmount();
    sdcard->deinit();
    output->putData(data);
    
    return;
    }


//Open and read on an existing file, Error if file do not exist
//Arg1: file name
void SDCard_read(Arguments *input,Reply *output){
    char odata[900],data[1024],fpath[1024];
    long int fsize;
    long int len = 0, r_ctr = 0;
    int err, c;
    
    int dev_stat = sdcard->init(); //Check if device is initialized
    if (dev_stat != 0){ //Init failed
        output->putData("Fail to initialize blockdevice");
        return;
        }
        
    int mount = fatfs.mount(sdcard);
    if(mount != 0){
        output->putData("Fail to mount to FATfs");
        return;
        }
        
    const char* path = input->getArg<const char*>();
    sprintf(fpath,"/fatfs/%s",path); //Unable to navigate a folder since "/" is a symbol sensitive to RPC
    FILE *file = fopen(fpath,"r"); //a for append, r for read, w for write, add b at the end to do it in binary form
    if(file == NULL){
        output->putData("Error in opening file");
        return;
        }
        
    fseek(file,0,SEEK_END);
    fsize = ftell(file);
    rewind(file); //Set pointer back to the beginning 
      
    if(fsize > 900){
            while(1) {
                c = fgetc(file);
                r_ctr++;
                if( feof(file) || r_ctr == 901) { 
                    break ;
                    }
            len += sprintf(odata + len,"%c",c);
            }
        if(r_ctr != 901){
            output->putData("Reading file error");
            return;
            }
        len = 0; //Reset len for "data"
        len += sprintf(data + len,"File Size: %d, Only first 900 Bytes shown\n",fsize);
        }        
    else{     
        while(1) {
            c = fgetc(file);
            if(feof(file)) { 
                break ;
                }
        len += sprintf(odata + len,"%c",c);
        r_ctr++;
        }
        if(r_ctr != fsize){
            output->putData("Reading file error");
            return;
            }
        len = 0; //Reset len for "data"
        len += sprintf(data + len,"File Size: %d\n",fsize);
        }
        
    err = ferror(file);
    if(err !=0){
        len += sprintf(data + len,"File Error flag raised\n");
        }
        
    fclose(file);

    len += sprintf(data + len,"File Data: %s",odata);
    fatfs.unmount();
    sdcard->deinit();
    output->putData(data);
    
    return;
    }


//Create/Overwrite a file and write
//Arg1: file name, Arg2: Data to write
void SDCard_write(Arguments *input,Reply *output){
    char fpath[1024];
    
    int dev_stat = sdcard->init(); //Check if device is initialized
    if (dev_stat != 0){ //Init failed
        output->putData("Fail to initialize blockdevice");
        return;
        }
        
    int mount = fatfs.mount(sdcard);
    if(mount != 0){
        output->putData("Fail to mount to FATfs");
        return;
        }
        
    const char* path = input->getArg<const char*>();
    sprintf(fpath,"/fatfs/%s",path); //Unable to navigate a folder since "/" is a symbol sensitive to RPC
    
    FILE *file = fopen(fpath,"w"); //a for append, r for read, w for write, add b at the end to do it in binary form
    if(file == NULL){
        output->putData("Error in opening file");
        return;
        }
        
    const char* idata = input->getArg<const char*>();    
    int suc = fwrite(idata,1,strlen(idata),file);//Arg: buffer pointer, size in bytes, number of elements each in size length, file 
    if (suc == strlen(idata)){ //Success in writing into file
        output->putData("Written");
        }
    else{
        output->putData("Error in writing to file");
        }

    fclose(file);
    fatfs.unmount(); 
    sdcard->deinit();   
    
    return;
    }


//Append on an existing file or create a file and write
//Arg1: file name, Arg2: Data to write/append
void SDCard_append(Arguments *input,Reply *output){
    char fpath[1024];
    
    int dev_stat = sdcard->init(); //Check if device is initialized
    if (dev_stat != 0){ //Init failed
        output->putData("Fail to initialize blockdevice");
        return;
        }
        
    int mount = fatfs.mount(sdcard);
    if(mount != 0){
        output->putData("Fail to mount to FATfs");
        return;
        }
        
    const char* path = input->getArg<const char*>();
    sprintf(fpath,"/fatfs/%s",path); //Unable to navigate a folder since "/" is a symbol sensitive to RPC
    
    FILE *file = fopen(fpath,"a"); //a for append, r for read, w for write, add b at the end to do it in binary form
    if(file == NULL){
        output->putData("Error in opening file");
        return;
        }
        
    const char* idata = input->getArg<const char*>();    
    int suc = fwrite(idata,1,strlen(idata),file);//Arg: buffer pointer, size in bytes, number of elements each in size length, file 
    if (suc == strlen(idata)){ //Success in writing into file
        output->putData("Written");
        }
    else{
        output->putData("Error in writing to file");
        }

    fclose(file);
    fatfs.unmount(); 
    sdcard->deinit();  
    
    return;    
    }