#ifndef RPC_SDCARD_H
#define RPC_SDCARD_H


void SDCard_setup(Arguments *input,Reply *output);


void SDCard_info(Arguments *input,Reply *output);


void SDCard_freq(Arguments *input,Reply *output);


void SDCard_filesize(Arguments *input,Reply *output);


void SDCard_read(Arguments *input,Reply *output);


void SDCard_write(Arguments *input,Reply *output);


void SDCard_append(Arguments *input,Reply *output);


#endif