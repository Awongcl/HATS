#ifndef RPC_I2C_H
#define RPC_I2C_H


void I2C_setup(Arguments *input,Reply *output);
    
    
void I2C_freq(Arguments *input,Reply *output);


void I2C_read(Arguments *input,Reply *output);


void I2C_write1(Arguments *input,Reply *output);


void I2C_write2(Arguments *input,Reply *output);


void I2C_scan(Arguments *input,Reply *output);


#endif