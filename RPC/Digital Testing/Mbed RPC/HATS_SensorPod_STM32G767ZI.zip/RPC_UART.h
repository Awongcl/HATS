#ifndef RPC_UART_H
#define RPC_UART_H


void UART_setup(Arguments *input,Reply *output);


void UART_baud(Arguments *input,Reply *output);


void UART_format(Arguments *input,Reply *output);


//void UART_flowctr(Arguments *input,Reply *output);


void UART_write(Arguments *input,Reply *output);


void UART_read(Arguments *input,Reply *output);


void UART_writeread(Arguments *input,Reply *output);


void UART_newline(Arguments *input,Reply *output);


#endif