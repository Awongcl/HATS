#include "mbed_rpc.h"
#include <iostream>
#include "RPC_I2C.h"
#include "mbed.h"
#include "I2C.h"

/* RPC I2C Notes
* I2C_Setup function must be called first before other functions. Pins for I2C SDA & I2C SCL must be declared successfully prior to usage
*/


//I2C Set-up
PinName I2CSDA;
PinName I2CSCL;
I2C *i2c;


//Set pin for I2C_SDA and I2C_SCL
//Arg1: SDA pin, Arg2: SCL pin
void I2C_setup(Arguments *input,Reply *output){
    I2CSDA = input->getArg<PinName>();
    I2CSCL = input->getArg<PinName>();
    
    i2c = new I2C(I2CSDA,I2CSCL);
    
    output->putData("I2C pin setup done!");
    
    return;
    }


//Modify I2C Frequency, default set to 100000 Hz
//Arg1: Frequency (Hz)    
void I2C_freq(Arguments *input,Reply *output){
    int hz = input->getArg<int>();
    
    i2c->frequency(hz);
    char buffer[256];
    sprintf(buffer,"I2C Frequency set to: %d Hz",hz);
    output->putData(buffer);
    
    return;
    }
    

//Read 1 or 2 bytes
//Arguments: slave addr, reg addr, 1/2 Bytes to read
void I2C_read(Arguments *input,Reply *output){
    int addr7bit = input->getArg<int>();
    int addr8bit = addr7bit<<1;
    int regaddr = input->getArg<int>();
    int bytes = input->getArg<int>();
    char subaddr[2] = {};
    char data[256];
    subaddr[0] = regaddr;
    
    i2c->write(addr8bit,&subaddr[0],1,true); //I2C write
    i2c->read(addr8bit,&subaddr[0],bytes,false); //I2C read
    
    //Read 1 or 2 bytes based on user input
    if (bytes == 1){
        sprintf(data,"Byte 1: %i",subaddr[0]);
        }
    else if(bytes == 2){
        sprintf(data,"Byte 1: %i, Byte 2: %i",subaddr[0], subaddr[1]);
        }
    else{
        output->putData("Invalid");
        }
        
    output->putData(data);
    return;
    }
 
 
  
//Write 1 byte
//arguments: slave addr, reg addr, byte 1  
 void I2C_write1(Arguments *input,Reply *output){
    int addr7bit = input->getArg<int>();
    int addr8bit = addr7bit<<1;
    int regaddr = input->getArg<int>();
    char subaddr[2] = {}; //reg addr + 1 byte to write
    subaddr[0] = regaddr;
    int buffer = input->getArg<int>();
    subaddr[1] = buffer;
    
    int response = i2c->write(addr8bit,&subaddr[0],2,false); //I2C Write
    
    if(response == 0){
        output->putData("Success");
        }
    else{
        output->putData("Failed");
        }
        
    return;
    }   
 
 
//Write 2 bytes
//arguments: slave addr, reg addr, byte 1, byte 2   
void I2C_write2(Arguments *input,Reply *output){
    int addr7bit = input->getArg<int>();
    int addr8bit = addr7bit<<1;
    int regaddr = input->getArg<int>();
    char subaddr[3] = {}; //reg addr + 2 bytes to write
    subaddr[0] = regaddr;
    int buffer = input->getArg<int>();
    subaddr[1] = buffer;
    buffer = input->getArg<int>();
    subaddr[2] = buffer;
    
    int response = i2c->write(addr8bit,&subaddr[0],3,false); //I2C Write
    
    if(response == 0){
        output->putData("Success");
        }
    else{
        output->putData("Failed");
        }
        
    return;
    }
    
    
//Scan for I2C Devices
void I2C_scan(Arguments *input,Reply *output){
    int ack, addr8bit;
    int addr = 1; //Start at 1 to exclude general call
    int num = 0;
    char devaddr[128] = {};
    char bufdata[256] = ""; //Ensure string is empty at start of function 
    char data[256], buf[256];
    
    while(addr<128){ //Iterate through all possible addresses
        addr8bit = addr << 1;    
        ack = i2c->write(addr8bit,NULL,0);
        wait(0.005);
        
        if (ack == 0) { //Check for response
            devaddr[num] = addr;
            num++;
            }    
            
        addr++;
    }
    
    int ctr = 0;
    
    if(num!=0){ //Number of I2C Device found
        while(ctr<num){
            if((ctr+1)==num){
                sprintf(buf,"%d",devaddr[ctr]);
                }
            else{
                sprintf(buf,"%d, ",devaddr[ctr]);
                }
            strcat(bufdata,buf);
            ctr++;
            }   
        sprintf(data,"I2C Devices found: %d. Addresses(7-bit): %s",num,bufdata);
        output->putData(data);
        }
    else{
        output->putData("No I2C Devices found");
        }
        
    return;
}
    
