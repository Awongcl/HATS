#include "mbed_rpc.h"
#include <iostream>
#include "RPC_UART.h"
#include "mbed.h"
#include "Serial.h"
#include "SerialBase.h"
#include "UARTSerial.h"

#define DEVICE_SERIAL_FC 1

/* RPC UART Notes
* UART_setup function must be called first before other functions. Pins for UART TX & UART RX must be declared successfully prior to usage
*/



//UART Set-up
PinName UARTTX, UARTRX;
Serial *uart;



//Set pin for UART interface
//Arg1: TX pin, Arg2: RX pin
void UART_setup(Arguments *input,Reply *output){
    UARTTX = input->getArg<PinName>();
    UARTRX = input->getArg<PinName>();
    
    uart = new Serial(UARTTX,UARTRX);
    output->putData("UART pin setup done!");
    
    return;
    }


//Set baudrate
//Arg1: baudrate
void UART_baud(Arguments *input,Reply *output){
    int baud = input->getArg<int>();
    uart->baud(baud);
    char data[256];
    
    sprintf(data,"Baudrate: %d",baud);
    output->putData(data);
    
    return;
    }
    
    
//Change UART format
//bits: The number of bits in a word (5-8; default = 8)
//parity: The parity used (SerialBase::None, SerialBase::Odd, SerialBase::Even, SerialBase::Forced1, SerialBase::Forced0; default = SerialBase::None
//stop_bits: The number of stop bits (1 or 2; default = 1)
//Arg1: Bits, Arg2: parity, Arg3: stopbits
void UART_format(Arguments *input,Reply *output){
    int bit = input->getArg<int>();
    const char* parity = input->getArg<const char*>();
    int stopbit = input->getArg<int>();
    
    if((bit <5) || (bit>8)){
        output->putData("Invalid bit");
        return;
        }
    else if((strcmp(parity,"None") != 0) && (strcmp(parity,"Odd")!= 0) && (strcmp(parity,"Even")!= 0) && (strcmp(parity,"Forced1")!= 0) && (strcmp(parity,"Forced0")!= 0)){
        output->putData("Invalid parity");
        return;
        }
    else if((stopbit!= 1) && (stopbit != 2)){
        output->putData("Invalid stopbit");
        return;
        }
    else{
        if(strcmp(parity,"None") == 0){
            uart->format(bit,uart->None,stopbit);
            }
        else if(strcmp(parity,"Odd")== 0){
            uart->format(bit,uart->Odd,stopbit);
            }
        else if(strcmp(parity,"Even")== 0){
            uart->format(bit,uart->Even,stopbit);
            }
        else if(strcmp(parity,"Forced1")== 0){
            uart->format(bit,uart->Forced1,stopbit);
            }
        else if(strcmp(parity,"Forced0")== 0){
            uart->format(bit,uart->Forced0,stopbit);
            }      
            
        char data[256];
        sprintf(data,"Bit: %d, Parity: %s, Stopbit: %d",bit,parity,stopbit);
        output->putData(data);
        }
        return;
    }

// To be implemented once RPC is upgradeable to mbed version with features
//     *  @param type the flow control type (Disabled, RTS, CTS, RTSCTS)
//     *  @param flow1 the first flow control pin (RTS for RTS or RTSCTS, CTS for CTS)
//     *  @param flow2 the second flow control pin (CTS for RTSCTS)
//void UART_flowctr(Arguments *input,Reply *output){
//    
////    PinName CTS = input->getArg<PinName>();
////    PinName RTS = input->getArg<PinName>();
////    uart.serial_set_flow_control(uart,FlowControlRTSCTS,PD_4,PD_3);
////    uart.set_flow_control(Flow RTSCTS,PD_4,PD_3);
//    }


//Write String into UART
//Arg1: Data to write
void UART_write(Arguments *input,Reply *output){
    const char* dataw = input->getArg<const char*>();
    int towrite = uart->writeable(); //Return 0 = No space to write, 1 = Space to write
    if (towrite == 0){
        output->putData("No space to write");
        return;
        }
    else{
        uart->printf("%s\r\n",dataw);
        output->putData("Written");
        return;
        }
        
    }
    

//Read String from UART     
//Arg1: Number of lines to read
void UART_read(Arguments *input,Reply *output){
    int toread = uart->readable(); //Return 0 = No data, 1 = Data
    int line = input->getArg<int>();
    
    if(line <= 0){
        output->putData("Invalid Argument");
        return;
        }
        
    int ctr = 0;
        if (toread == 1){
            char data[256];
            char buffer[256];
            strcpy(buffer,""); //Make sure string is empty
            while(true){
                char response = uart->getc();
                if(response == '\n'){
                    ctr++;
                    if(line == ctr){
                        break;
                        }
                    }
                strcat(buffer,&response); //To avoid appending \n to buffer string
            }
            sprintf(data,"Data: %s",buffer);
            output->putData(data);
            }
        else{
            output->putData("No data to read");
            }
            
        return;
    }
    

//Create an if for multiple lines valid numbers
//Arg1: Data to write, Arg2: Number of lines to read
void UART_writeread(Arguments *input,Reply *output){
    const char* dataw = input->getArg<const char*>();
    int line = input->getArg<int>();
    int ctr = 0;
    char data[256];
    char buffer[256];
    strcpy(buffer,""); //Make sure string is empty  
    if(line <= 0){ //Make sure number of lines to read is positive
        output->putData("Invalid Argument");
        return;
        }
    int towrite = uart->writeable(); //Return 0 = No space to write, 1 = Space to write
    if (towrite == 0){
        output->putData("No space to write");
        return;
        }
    else{
        uart->printf("%s\r\n",dataw);
        output->putData("Written");
        int toread = uart->readable(); //Return 0 = No data, 1 = Data
        if(toread==1){
            while(true){
                char response = uart->getc();
                if( response == '\n'){
                    ctr++;                    
                    if(ctr == line){
                        break;
                        }
                    }
                strcat(buffer,&response);   
                }
            sprintf(data,"Data: %s",buffer);
            output->putData(data);
            }
        else{
            output->putData("No data to read");
            }
        }
        return;
    }


//Send in newline to UART port
//No Argument
void UART_newline(Arguments *input,Reply *output){
    int towrite = uart->writeable(); //Return 0 = No space to write, 1 = Space to write
    if (towrite == 0){
        output->putData("No space to write");
        }
    else{
       uart->printf("\n");
        output->putData("Newline");
        }
    return;
    }
