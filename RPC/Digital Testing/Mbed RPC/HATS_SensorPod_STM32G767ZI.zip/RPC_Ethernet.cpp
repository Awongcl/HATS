#include "mbed_rpc.h"
#include "EthernetInterface.h"
#include "mbed.h"
#include "rtos.h"
#include "RPC_Ethernet.h"


/* RPC Ethernet Notes
* In order to use ethernet without DHCP, I, GATEWAY , MASK will have to be declared in Eth_staticvar
*/

EthernetInterface eth;
TCPSocket socket;
Timer t;

//Variables
char ipbuf[256];
char gatewaybuf[256];
char maskbuf[256];
char destipbuf[256];
char idatabuf[256];

const char *STATIC_IP = ipbuf;
const char *STATIC_GATEWAY = gatewaybuf;
const char *STATIC_MASK = maskbuf;
const char *DEST_IP = destipbuf;
int DEST_PORT;
const char *IDATA = idatabuf;


//Setup IP, GATEWAY, MASK for device manually
//Arg1: IP Address, Arg2: GATEWAY, Arg3: MASK
void Eth_staticvar(Arguments *input,Reply *output){
    char data[256];
    
    const char *ip = input->getArg<const char*>();
    const char *gateway = input->getArg<const char*>();
    const char *mask = input->getArg<const char*>();
      
    sprintf(ipbuf,"%s",ip);
    sprintf(gatewaybuf,"%s",gateway);
    sprintf(maskbuf,"%s",mask);    
    
    sprintf(data,"Static IP: %s, Static GATEWAY: %s, Static MASK: %s",STATIC_IP,STATIC_GATEWAY,STATIC_MASK);
    output->putData(data);
    
    return;
    }


//Read static variable that has been declared
//No Argument
void Eth_readvar(Arguments *input,Reply *output){
    char data[512];
    
    sprintf(data,"Static IP: %s, Static GATEWAY: %s, Static MASK: %s",STATIC_IP,STATIC_GATEWAY,STATIC_MASK);
    output->putData(data);
    return;    
    }    


//Ethernet using static IP
//Arg1: Destination IP, Arg2: Destination port, Arg3:Data to send
void Eth_static(Arguments *input,Reply *output){
    int ret;
    char sdata[256];
    char rdata[256];
    char rpcdata[512];
    nsapi_size_t ssize,rsize;
    
    DEST_IP = input->getArg<const char*>(); //Dest IP Address
    DEST_PORT = input->getArg<int>(); //Dest port
    IDATA = input->getArg<const char*>(); //Data to send

    sprintf(sdata,"%s",IDATA);
    
    eth.get_default_instance();

    //Static set-up
    ret = eth.set_network(STATIC_IP,STATIC_MASK,STATIC_GATEWAY); //param const char *ip_address, const char *netmask, const char *gateway return 0 if success, negative number if failed
    if(ret !=0){
        output->putData("Failed to set-up network\n");
        return;
        }
    else{
        output->putData("IP set-up done\n");
        }
        
    ret = eth.connect();
    if(ret !=0){ //Check for connection
        output->putData("Failed to start interface\n");
        return;
        }

    socket.open(&eth);
    socket.connect(DEST_IP,DEST_PORT); //IP Address, port number
    
    //Send
    ssize = strlen(sdata);
    t.start();
    ssize = socket.send(sdata,ssize);
    sprintf(rpcdata,"Bytes sent: %d\n",ssize);
    output->putData(rpcdata);

    //Receive
    rsize = socket.recv(rdata,256);
    t.stop();
    sprintf(rpcdata,"Bytes received: %d\n",rsize);
    output->putData(rpcdata);
    sprintf(rpcdata,"RTT: %fs\n",t.read());
    output->putData(rpcdata);
    sprintf(rpcdata,"Data Received: %s\n",rdata);
    output->putData(rpcdata);

    
    //Stop Interface
    socket.close();
    ret = eth.disconnect();
    if(ret !=0){ //Check for disconnect
        output->putData("Failed to stop interface\n");
        }  
        
    return;
    }
        
    
//Ethernet using DHCP
//Arg1: Destination IP, Arg2: Destination port, Arg3: Data to send
void Eth_DHCP(Arguments *input,Reply *output){
    int ret;
    char sdata[256];
    char rdata[256];
    char rpcdata[512];
    nsapi_size_t ssize,rsize;
    
    DEST_IP = input->getArg<const char*>(); //Dest IP Address
    DEST_PORT = input->getArg<int>(); //Dest port
    IDATA = input->getArg<const char*>(); //Data to send
    
    sprintf(sdata,"%s",IDATA);
    
    eth.get_default_instance();
    
    //Use DHCP
    ret = eth.set_dhcp(true); //True to enable DHCP ,return 0 if success, negative number if failed
    if (ret != 0){ //Check DHCP Set-up
        output->putData("DHCP Set-up failed\n");
        return;
        }
    else{
        output->putData("DHCP Set-up complete\n");
        }      
    
    ret = eth.connect(); 
    if(ret !=0){ //Check for connection
        output->putData("Failed to start interface\n");
        }
    
    socket.open(&eth);
    socket.connect(DEST_IP,DEST_PORT); //IP Address, port number
    
    //Send
    ssize = strlen(sdata);
    t.start();
    ssize = socket.send(sdata,ssize);
    sprintf(rpcdata,"Bytes sent: %d\n",ssize);
    output->putData(rpcdata);

    //Receive
    rsize = socket.recv(rdata,256);
    t.stop();
    sprintf(rpcdata,"Bytes received: %d\n",rsize);
    output->putData(rpcdata);
    sprintf(rpcdata,"RTT: %fs\n",t.read());
    output->putData(rpcdata);
    output->putData("Data Received: ");
    sprintf(rpcdata,"%s",rdata);
    output->putData(rpcdata);

    
    //Stop Interface
    socket.close();
    ret = eth.disconnect();
    if(ret !=0){ //Check for disconnect
        output->putData("Failed to stop interface\n");
        return;
        }  
        
    return;
    }
