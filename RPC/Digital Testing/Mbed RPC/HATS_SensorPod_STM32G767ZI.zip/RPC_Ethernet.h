#ifndef RPC_Ethernet_H
#define RPC_Ethernet_H

extern char ipbuf[256];
extern char gatewaybuf[256];
extern char maskbuf[256];
extern char destipbuf[256];
extern char idatabuf[256];


extern const char *STATIC_IP;
extern const char *STATIC_GATEWAY;
extern const char *STATIC_MASK;
extern const char *DEST_IP;
extern int DEST_PORT;
extern const char *IDATA; 
extern const char *OUTDATA;


void Eth_staticvar(Arguments *input,Reply *output);


void Eth_readvar(Arguments *input,Reply *output);


void Eth_static(Arguments *input,Reply *output);


void Eth_DHCP(Arguments *input,Reply *output);


#endif